#__init__.py
from CovidSonglinePawit.covidreport import report